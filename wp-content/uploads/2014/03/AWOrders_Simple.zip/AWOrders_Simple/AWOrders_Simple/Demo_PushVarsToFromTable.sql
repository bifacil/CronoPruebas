/* 
This query is from the GetAuditKey Execute SQL task in the MASTER PACKAGE.
It shows how to pass parameters into a SQL statement, and get a value
back out. Syntax uses the .Net provider
*/

INSERT INTO DimAudit (
ParentAuditKey, TableName, 
PkgName, PkgGUID, PkgVersionGUID, PkgVersionMajor, 
PkgVersionMinor, ExecStartDT, TableInitialRowCnt)
Values (@ParentAuditKey, @TableName,
@PkgName, @PkgGUID, @PkgVersionGUID, @PkgVersionMajor, 
@PkgVersionMinor, @ExecStartDT, @RowCount)

-- Get the key we just entered.
SELECT cast(IDENT_CURRENT( 'DimAudit' ) AS int) AS AuditKey
