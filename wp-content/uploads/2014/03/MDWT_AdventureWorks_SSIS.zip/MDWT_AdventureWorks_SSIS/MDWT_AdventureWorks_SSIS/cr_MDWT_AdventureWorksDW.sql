/****** Object:  Database MDWT_AdventureWorksDW    Script Date: 6/8/2006 1:00:48 PM ******/
/*
Kimball Group, The Microsoft Data Warehouse Toolkit
Generate a database from the datamodel worksheet

You can use this Excel workbook as a data modeling tool during the logical design phase of your project.
As discussed in the book, it is in some ways preferable to a real data modeling tool during the inital design.
We expect you to move away from this spreadsheet and into a real modeling tool during the physical design phase.
The authors provide this macro so that the spreadsheet isn't a dead-end. You can 'import' into your
data modeling tool by generating a database using this script, then reverse-engineering that database into
your tool.

Uncomment the next lines if you want to drop and create the database
*/
/*
DROP DATABASE MDWT_AdventureWorksDW
GO
CREATE DATABASE MDWT_AdventureWorksDW
GO
*/
USE MDWT_AdventureWorksDW
GO
EXEC sys.sp_addextendedproperty @name = 'Description', @value = 'Forward Engineer from MDWT Excel workbook'
GO





/* Drop table DimCustomer */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimCustomer]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimCustomer] 
GO

/* Create table DimCustomer */
CREATE TABLE [DimCustomer] (
   [CustomerKey]  int IDENTITY  NOT NULL
,  [BKAccountNumber]  varchar(10)   NOT NULL
,  [CustomerType]  char(10)   NOT NULL
,  [CustomerIDName]  varchar(100)   NULL
,  [CustomerTitle]  char(5)   NULL
,  [FirstName]  varchar(30)   NULL
,  [MiddleName]  varchar(30)   NULL
,  [LastName]  varchar(30)   NULL
,  [CustomerFullName]  varchar(100)   NULL
,  [BirthDate]  datetime   NULL
,  [MaritalStatus]  char(7)   NULL
,  [Gender]  char(7)   NULL
,  [EmailAddress]  varchar(50)   NULL
,  [IncomeRange]  varchar(50)   NULL
,  [TotalChildren]  tinyint   NULL
,  [NumberChildrenAtHome]  tinyint   NULL
,  [Education]  varchar(30)   NULL
,  [Occupation]  varchar(30)   NULL
,  [HomeOwnerStatus]  varchar(13)   NULL
,  [NumberCarsOwned]  tinyint   NULL
,  [DateFirstPurchase]  datetime   NULL
,  [CommuteDistance]  varchar(15)   NULL
,  [CustomerValueScore]  varchar(15)   NULL
,  [Phone]  varchar(20)   NULL
,  [AddressLine1]  varchar(60)   NULL
,  [AddressLine2]  varchar(60)   NULL
,  [PostalCode]  varchar(15)   NULL
,  [City]  varchar(100)   NULL
,  [CityAsRecorded]  varchar(100)   NULL
,  [StateProvinceCode]  char(3)   NULL
,  [StateProvince]  varchar(50)   NULL
,  [CountryCode]  char(3)   NULL
,  [Country]  varchar(50)   NULL
,  [ResellerName]  varchar(50)   NULL
,  [BusinessType]  varchar(20)   NULL
,  [BKCustomerSalesTerritoryId]  int   NULL
,  [CustomerSalesTerritory]  varchar(50)   NULL
,  [CustomerSalesTerritoryCountry]  varchar(50)   NULL
,  [CustomerSalesTerritoryGroup]  varchar(50)   NULL
,  [NumberEmployees]  int   NULL
,  [AnnualSales]  money   NULL
,  [AnnualRevenue]  money   NULL
,  [YearOpened]  int   NULL
,  [BankName]  varchar(50)   NULL
,  [OrderFrequency]  char(12)   NULL
,  [CurrentStoreValueScore]  char(12)   NULL
,  [FirstOrderDate]  datetime   NULL
,  [LastOrderDate]  datetime   NULL
,  [RowIsCurrent]  char(1)   NULL
,  [RowStartDate]  datetime   NULL
,  [RowEndDate]  datetime  DEFAULT '12/31/9999' NULL
,  [RowChangeReason]  varchar(200)   NULL
,  [AuditKey]  int   NOT NULL
, CONSTRAINT [PK_DimCustomer] PRIMARY KEY CLUSTERED 
( [CustomerKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'Customer', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'The Customer dimension includes all Adventure Works customers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'Orders, Returns, CustomerCare, Shipping', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer'
GO

SET IDENTITY_INSERT DimCustomer ON
GO
INSERT INTO DimCustomer (CustomerKey, BKAccountNumber, CustomerType, CustomerIDName, CustomerTitle, FirstName, MiddleName, LastName, CustomerFullName, BirthDate, MaritalStatus, Gender, EmailAddress, IncomeRange, TotalChildren, NumberChildrenAtHome, Education, Occupation, HomeOwnerStatus, NumberCarsOwned, DateFirstPurchase, CommuteDistance, CustomerValueScore, Phone, AddressLine1, AddressLine2, PostalCode, City, CityAsRecorded, StateProvinceCode, StateProvince, CountryCode, Country, ResellerName, BusinessType, BKCustomerSalesTerritoryId, CustomerSalesTerritory, CustomerSalesTerritoryCountry, CustomerSalesTerritoryGroup, NumberEmployees, AnnualSales, AnnualRevenue, YearOpened, BankName, OrderFrequency, CurrentStoreValueScore, FirstOrderDate, LastOrderDate, RowIsCurrent, RowStartDate, RowEndDate, RowChangeReason, AuditKey)
VALUES (-1, 'Unknown', 'Unknown', 'Unknown', NULL, 'Unknown', 'Unknown', 'Unknown', 'Unknown', NULL, 'Unknown', 'Unknown', 'Unknown', NULL, NULL, NULL, 'Unknown', 'Unknown', 'Unknown', NULL, NULL, 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'N/A', 'Unknown', 'N/A', 'Unknown', 'Unknown', 'Unknown', NULL, 'Unknown', 'Unknown', 'Unknown', NULL, NULL, NULL, NULL, 'Unknown', 'Unknown', 'Unknown', NULL, NULL, 'Y', NULL, '12/31/9999', 'N/A', -1)
GO
SET IDENTITY_INSERT DimCustomer OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Account Number from the transaction system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKAccountNumber'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'The type of the customer based on our relationship', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer full name (Last, First Middle) prepended with CustomerID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerIDName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Courtesy title', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s first name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s middle name (often NULL)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MiddleName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s last name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s full name as Last, First Middle', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerFullName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s date of birth', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s marital status', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s gender', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s email address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'EmailAddress'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s annual Income', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s total number of children', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s number of children at home', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s education level', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s general occupation (eg Managerial)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is the customer a homeowner?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Number of cars the customer owns', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date person first purchased a bike (self-reported)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s average commute distance', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s current lifetime value score to AdventureWorks', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerValueScore'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer''s phone number', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Phone'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'First line of customer''s address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'2nd line of customer''s address (usually NULL)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Postal code, eg zip code', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'City, cleaned up by way of postal code', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'City'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'City as it actually exists in the source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'State or Province code', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'State or Province', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Country code', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Country', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Reselling store''s name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'ResellerName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Reseller''s business type', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Natural key for the customer''s current sales territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer sales territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer sales territory country', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Customer sales territory group', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Number of employees at the store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Store''s annual sales, self-reported', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Store''s annual revenue, self-reported', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Year the store opened', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Store''s bank name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Does this reseller tend to order Annually, Semiannually, or Quarterly?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'OrderFrequency'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Current store value to AdventureWorks', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CurrentStoreValueScore'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date store first ordered from us', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstOrderDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date store most recently ordered from us', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastOrderDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is this the current row for this member (Y/N)?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'When did this row become valid for this member?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'When did this row become invalid? (12/31/9999 if current row)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Why did the row change last?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowChangeReason'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What process loaded this row?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3, 4 �', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'AW00000001', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKAccountNumber'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Reseller, Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Ms., Mr.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Tom, Dick, Harry', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Married, Single, Unknown', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Male, Female, Unknown', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Homeowner, Not Homeowner', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'3/19/2004', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1/14/1998, 12/31/9999', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerIDName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MiddleName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerFullName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'EmailAddress'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerValueScore'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Phone'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'City'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'ResellerName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'OrderFrequency'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CurrentStoreValueScore'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstOrderDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastOrderDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKAccountNumber'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerIDName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerFullName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'EmailAddress'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerValueScore'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Phone'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'City'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'ResellerName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'OrderFrequency'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CurrentStoreValueScore'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstOrderDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastOrderDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowChangeReason'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKAccountNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'EmailAddress'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Phone'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'ResellerName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Customer', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKAccountNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Customer', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'EmailAddress'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Individual', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Phone'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CustomerAddress', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CustomerAddress', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'StateProvince', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'StateProvince', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CountryRegion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'ResellerName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Customer', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesTerritory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CountryRegion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesTerritory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Store', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'AccountNumber', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKAccountNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'CustomerType', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Title', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'FirstName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'MiddleName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'LastName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'EmailAddress', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'EmailAddress'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Phone', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Phone'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'AddressLine1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'AddressLine2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'PostalCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'City', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'StateProvinceCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'CountryRegionCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'ResellerName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'TerritoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Group', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Demographics', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'varchar(10)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKAccountNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(8)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerTitle'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'EmailAddress'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(25)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Phone'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(60)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(60)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(15)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(30)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'City'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(30)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(3)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(3)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'xml', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode CustomerType from S/I to Reseller/Individual else Unknown', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerType'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'AcctNum + '' '' + DW.FullName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerIDName'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'LastName + '', '' + FirstName + '' '' + MiddleName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerFullName'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <BirthDate>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <MaritalStatus>. Decode to Single/Married', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <Gender>. Decode to Female/Male/Unknown', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <YearlyIncome>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'IncomeRange'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <TotalChildren>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'TotalChildren'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <NumberChildrenAtHome>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberChildrenAtHome'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <Education>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Education'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <Occupation>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Occupation'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <HouseOwnerFlag>. Decode to Homeowner / Not Homeowner', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'HomeOwnerStatus'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <NumberCarsOwned>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberCarsOwned'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <DateFirstPurchase>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'DateFirstPurchase'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <CommuteDistance>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CommuteDistance'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Out of scope for Phase 1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerValueScore'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from Person.Contact on CustomerID; pick up the most recent address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine1'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'see notes for AddrLine1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AddressLine2'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'see notes for AddrLine1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'PostalCode'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Out of scope for Phase 1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'City'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'see notes for AddrLine1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CityAsRecorded'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from Person.Address.StateProvinceId', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvinceCode'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from Person.Address.StateProvinceId', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'StateProvince'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from Person.StateProvince.CountryRegionCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CountryCode'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from Person.StateProvince.CountryRegionCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'Country'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <BusinessType>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BusinessType'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on Customer.SalesTerritoryID= SalesTerritory.SalesTerritoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join to Sales.SalesTerritory on TerritoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from SalesTerritory to CountryRegion on CountryRegionCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'see note for Current_Sales_Territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <NumberEmployees>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'NumberEmployees'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <AnnualSales>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualSales'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <AnnualRevenue>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AnnualRevenue'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <YearOpened>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'YearOpened'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Shred Demographics: <BankName>', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BankName'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Out of scope for Phase 1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'OrderFrequency'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Out of scope for Phase 1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CurrentStoreValueScore'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Derived from order trxns. Post-load update.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstOrderDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Derived from order trxns. Post-load update.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastOrderDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'RowChangeReason'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard Audit dim', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Data mining', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerValueScore'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Customer Sales Territory assigned at time of first order - does not seem to ever change.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'BKCustomerSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'We may want to do this decoding in the ETL; copy CountryRegion to staging area?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CustomerSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Look at pattern of orders: annual? Quarterly?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'OrderFrequency'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Data mining', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'CurrentStoreValueScore'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'After load, look for 1st trxn for any dim rows where first_order_date is null (ongoing, should be today''s load)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'FirstOrderDate'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'After fact load, update all dim rows where there was an order today', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCustomer', @level2type=N'COLUMN', @level2name=N'LastOrderDate'; 
GO





/* Drop table DimCurrency */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimCurrency]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimCurrency] 
GO

/* Create table DimCurrency */
CREATE TABLE [DimCurrency] (
   [CurrencyKey]  smallint IDENTITY  NOT NULL
,  [BKCurrencyCode]  char(3)   NOT NULL
,  [Currency]  varchar(50)   NOT NULL
,  [IsCurrencyInUse]  char(1)   NOT NULL
,  [AuditKey]  int   NOT NULL
, CONSTRAINT [PK_DimCurrency] PRIMARY KEY CLUSTERED 
( [CurrencyKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'Currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Dimension table that itemizes different currencies', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency'
GO

SET IDENTITY_INSERT DimCurrency ON
GO
INSERT INTO DimCurrency (CurrencyKey, BKCurrencyCode, Currency, IsCurrencyInUse, AuditKey)
VALUES (-1, 'UNK', 'Unknown', 'Y', -1)
GO
SET IDENTITY_INSERT DimCurrency OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Currency Code from trxn system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'BKCurrencyCode'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Currency name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is this currency currently in use in the system?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'IsCurrencyInUse'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What process loaded this row?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Dollar, Euro', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'IsCurrencyInUse'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'IsCurrencyInUse'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'BKCurrencyCode'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'IsCurrencyInUse'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'BKCurrencyCode'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'BKCurrencyCode'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'CurrencyCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'BKCurrencyCode'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(3)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'BKCurrencyCode'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'Currency'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Populate only as we encounter a new ToCurrency in the Sales data.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'BKCurrencyCode'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Derived in ETL, from the distinct set of currency codes in Sales.CurrencyRate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimCurrency', @level2type=N'COLUMN', @level2name=N'IsCurrencyInUse'; 
GO





/* Drop table DimDate */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimDate]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimDate] 
GO

/* Create table DimDate */
CREATE TABLE [DimDate] (
   [DateKey]  int   NOT NULL
,  [FullDate]  datetime   NULL
,  [DateName]  char(11)   NULL
,  [DayOfWeek]  tinyint   NULL
,  [DayNameOfWeek]  char(10)   NULL
,  [DayOfMonth]  tinyint   NULL
,  [DayOfYear]  smallint   NULL
,  [WeekdayWeekend]  char(7)   NULL
,  [WeekOfYear]  tinyint   NULL
,  [MonthName]  char(10)   NULL
,  [MonthOfYear]  tinyint   NULL
,  [IsLastDayOfMonth]  char(1)   NULL
,  [CalendarQuarter]  tinyint   NULL
,  [CalendarYear]  smallint   NULL
,  [CalendarYearMonth]  char(7)   NULL
,  [CalendarYearQtr]  char(7)   NULL
,  [FiscalMonthOfYear]  tinyint   NULL
,  [FiscalQuarter]  tinyint   NULL
,  [FiscalYear]  int   NULL
,  [FiscalYearMonth]  char(9)   NULL
,  [FiscalYearQtr]  char(8)   NULL
,  [AuditKey]  int   NOT NULL
, CONSTRAINT [PK_DimDate] PRIMARY KEY CLUSTERED 
( [DateKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'Date', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date dimension contains one row for every day, beginning at 1/1/2000. There may also be rows for "hasn''t happened yet."', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'Sales (3 roles); Finance; Currency Rates; Sales Quota (2 roles; one at Cal Qtr level)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate'
GO

SET IDENTITY_INSERT DimDate ON
GO
INSERT INTO DimDate (DateKey, FullDate, DateName, DayOfWeek, DayNameOfWeek, DayOfMonth, DayOfYear, WeekdayWeekend, WeekOfYear, MonthName, MonthOfYear, IsLastDayOfMonth, CalendarQuarter, CalendarYear, CalendarYearMonth, CalendarYearQtr, FiscalMonthOfYear, FiscalQuarter, FiscalYear, FiscalYearMonth, FiscalYearQtr, AuditKey)
VALUES (-1, NULL, 'Unknown', NULL, 'Unknown', NULL, NULL, 'Unknown', NULL, 'Unknown', NULL, 'N', NULL, NULL, 'Unknown', 'Unknown', NULL, NULL, NULL, 'Unknown', 'Unknown', -1)
GO
SET IDENTITY_INSERT DimDate OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Full date as a SQL date (time=00:00:00)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FullDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'String expression of the full date in users'' favored format', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Number of the day of week; Sunday = 1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfWeek'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Day name of week', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayNameOfWeek'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Number of the day in the month', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Number of the day in the year', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfYear'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is today a weekday or a weekend', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekdayWeekend'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Week of year', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekOfYear'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Month name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Month of year', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is this the last day of the calendar month?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'IsLastDayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Calendar quarter', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarQuarter'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Calendar year', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYear'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Calendar year and month', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearMonth'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Calendar year and quarter', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearQtr'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Fiscal month of year (1..12). FY starts in July', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalMonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Fiscal quarter', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalQuarter'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Fiscal year. Fiscal year begins in July.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYear'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Fiscal year and month', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearMonth'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Fiscal year and quarter', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearQtr'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What process loaded this row?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'20041123', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'11/23/2004', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FullDate'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'23-Nov-2004', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1..7', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfWeek'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Sunday', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayNameOfWeek'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1..31', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1..365', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfYear'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Weekday, Weekend', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekdayWeekend'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1..52 or 53', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekOfYear'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'November', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, �, 12', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'IsLastDayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3, 4', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarQuarter'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'2004', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYear'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'2004-01', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearMonth'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'2004Q1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearQtr'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, �, 12', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalMonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3, 4', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalQuarter'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'2004', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYear'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'FY2004-01', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearMonth'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'FY2004Q1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearQtr'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfWeek'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayNameOfWeek'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfYear'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekdayWeekend'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekOfYear'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'IsLastDayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarQuarter'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYear'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearMonth'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearQtr'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalMonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalQuarter'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYear'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearMonth'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearQtr'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FullDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfWeek'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayNameOfWeek'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DayOfYear'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekdayWeekend'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'WeekOfYear'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'MonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'IsLastDayOfMonth'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarQuarter'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYear'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearMonth'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'CalendarYearQtr'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalMonthOfYear'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalQuarter'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYear'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearMonth'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'FiscalYearQtr'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'In the form: yyyymmdd', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimDate', @level2type=N'COLUMN', @level2name=N'DateKey'; 
GO





/* Drop table DimEmployee */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimEmployee]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimEmployee] 
GO

/* Create table DimEmployee */
CREATE TABLE [DimEmployee] (
   [EmployeeKey]  int IDENTITY  NOT NULL
,  [BKEmployeeID]  int   NOT NULL
,  [NationalIDNumber]  char(15)   NOT NULL
,  [EmployeeIDName]  varchar(125)   NULL
,  [EmployeeFullName]  varchar(100)   NULL
,  [EmployeeFirstName]  varchar(50)   NULL
,  [EmployeeLastName]  varchar(50)   NULL
,  [EmployeeMiddleName]  varchar(50)   NULL
,  [BKManagerID]  int   NULL
,  [ManagerFullName]  varchar(100)   NULL
,  [ManagerEmail]  varchar(50)   NULL
,  [BirthDate]  datetime   NULL
,  [MaritalStatus]  char(7)   NULL
,  [Gender]  char(7)   NULL
,  [IsSalaried]  char(1)   NULL
,  [IsCurrentEmployee]  char(1)   NULL
,  [IsSalesPerson]  char(1)   NULL
,  [JobTitle]  varchar(50)   NULL
,  [DepartmentID]  int   NULL
,  [Department]  varchar(50)   NULL
,  [DepartmentGroup]  varchar(50)   NULL
,  [BKCurrentSalesTerritoryId]  int   NULL
,  [CurrentSalesTerritory]  varchar(50)   NULL
,  [CurrentSalesTerritoryCountry]  varchar(50)   NULL
,  [CurrentSalesTerritoryGroup]  varchar(50)   NULL
,  [BKHistoricalSalesTerritoryId]  int   NULL
,  [HistoricalSalesTerritory]  varchar(50)   NULL
,  [HistoricalSalesTerritoryCountry]  varchar(50)   NULL
,  [HistoricalSalesTerritoryGroup]  varchar(50)   NULL
,  [HireDate]  datetime   NULL
,  [EmploymentEndDate]  datetime   NULL
,  [LoginID]  varchar(50)   NULL
,  [EmployeeEmail]  varchar(50)   NULL
,  [EmployeePhone]  varchar(25)   NULL
,  [RowIsCurrent]  char(1)   NULL
,  [RowStartDate]  datetime   NULL
,  [RowEndDate]  datetime  DEFAULT '12/31/9999' NULL
,  [RowChangeReason]  varchar(200)   NULL
,  [AuditKey]  int   NOT NULL
, CONSTRAINT [PK_DimEmployee] PRIMARY KEY CLUSTERED 
( [EmployeeKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee info, including sales territory for sales reps', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'Orders', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee'
GO

SET IDENTITY_INSERT DimEmployee ON
GO
INSERT INTO DimEmployee (EmployeeKey, BKEmployeeID, NationalIDNumber, EmployeeIDName, EmployeeFullName, EmployeeFirstName, EmployeeLastName, EmployeeMiddleName, BKManagerID, ManagerFullName, ManagerEmail, BirthDate, MaritalStatus, Gender, IsSalaried, IsCurrentEmployee, IsSalesPerson, JobTitle, DepartmentID, Department, DepartmentGroup, BKCurrentSalesTerritoryId, CurrentSalesTerritory, CurrentSalesTerritoryCountry, CurrentSalesTerritoryGroup, BKHistoricalSalesTerritoryId, HistoricalSalesTerritory, HistoricalSalesTerritoryCountry, HistoricalSalesTerritoryGroup, HireDate, EmploymentEndDate, LoginID, EmployeeEmail, EmployeePhone, RowIsCurrent, RowStartDate, RowEndDate, RowChangeReason, AuditKey)
VALUES (-1, -1, 'Unknown Member', 'Unknown Member', 'Unknown', 'Unknown', 'Unknown', 'Unknown', NULL, 'Unknown', 'Unknown', NULL, 'Unknown', 'Unknown', 'U', 'U', 'U', 'Unknown', -1, 'Unknown', 'Unknown', NULL, 'Unknown', 'Unknown', 'Unknown', NULL, 'Unknown', 'Unknown', 'Unknown', NULL, NULL, 'Unknown', 'Unknown', 'Unknown', 'Y', NULL, '12/31/9999', 'N/A', -1)
GO
SET IDENTITY_INSERT DimEmployee OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee ID used in the transaction system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKEmployeeID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'National ID Number (eg SSN) for employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee full name prepended with national ID# (eg SSN)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeIDName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee full name: last, first middle', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee''s first name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee''s last name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee''s middle name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Manager ID used in the transaction system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Manager''s full name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerFullName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Manager''s email address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerEmail'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee''s birth date', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What is the employee''s marital status?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What is the employee''s gender?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is the employee salaried?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is this person currently an employee?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is the employee a sales person?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalesPerson'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee''s job title', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'JobTitle'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Department ID from the source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Department', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Department group', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Natural key for the employee''s current sales territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Current sales territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Current sales territory country', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Current sales territory group', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Natural key for the employee''s historical sales territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Historical sales territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Historical sales territory country', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Historical sales territory group', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date employee was hired', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date employment ended; 12/31/9999 if a current employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmploymentEndDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee''s login ID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Employee''s email address', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Phone number', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is this the current row for this member (Y/N)?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'When did this row become valid for this member?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'When did this row become invalid? (12/31/9999 if current row)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Why did the row change last?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowChangeReason'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What process loaded this row?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'273', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKEmployeeID'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'112432117', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'273 Welcker, Brian S ', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeIDName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Welcker, Brian S', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Brian', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Welcker', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'S', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'109', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'S�nchez, Ken J', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerFullName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'ken0@adventure-works.com', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerEmail'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'3/2/1959', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Married, Single, Unknown', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Male, Female, Unknown', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalesPerson'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Design Engineer', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'JobTitle'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Sales and Marketing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'adventure-works\brian3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'brian3@adventure-works.com', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'716-555-0127', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'3/19/2004', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1/14/1998, 12/31/9999', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeIDName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerFullName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerEmail'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalesPerson'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'JobTitle'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmploymentEndDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKEmployeeID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeIDName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerFullName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerEmail'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalesPerson'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'JobTitle'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmploymentEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowChangeReason'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKEmployeeID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeIDName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'JobTitle'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'HumanResources', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Person', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKEmployeeID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeIDName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'JobTitle'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'EmployeeDepartmentHistory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Department', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Department', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesPerson', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesTerritory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CountryRegion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesTerritory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesPerson', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesTerritory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CountryRegion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesTerritory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Employee', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Contact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'EmployeeId', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKEmployeeID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'NationalIdNumber', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'several', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeIDName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'several', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'FirstName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'LastName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'MiddleName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ManagerId', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'BirthDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'MaritalStatus', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Gender', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'SalariedFlag', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'CurrentFlag', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Title', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'JobTitle'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'DepartmentId', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'GroupName', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'TerritoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Group', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'TerritoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Group', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'HireDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'LoginId', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'EmailAddress', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Phone', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKEmployeeID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(15)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFirstName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeLastName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeMiddleName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKManagerID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'datetime', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(1)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(1)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'bit', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'bit', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'smallint', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'datetime', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(100)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'LoginID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeEmail'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(25)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeePhone'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Strip out all spaces and hyphens', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Last, First Middle', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmployeeFullName'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Self-join Employee on ManagerId to pick up manager ContactId; join to Person.Contact. Probably best to do in ETL flow.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerFullName'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'see Manager_Full_Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'ManagerEmail'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode M/S to Married/Single', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'MaritalStatus'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode M/F to Male/Femeale', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode 1/0 to Y/N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalaried'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode 1/0 to Y/N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsCurrentEmployee'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Sales person if HumanResources.Employee. EmployeeID IN Sales.SalesPerson.SalesPersonID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'IsSalesPerson'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on DepartmentID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on DepartmentID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on EmployeeID=SalesPersonID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join to Sales.SalesPerson on TerritoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from SalesTerritory to CountryRegion on CountryRegionCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'see note for Current_Sales_Territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on EmployeeID=SalesPersonID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join to Sales.SalesPerson on TerritoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join from SalesTerritory to CountryRegion on CountryRegionCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'see note for Historical_Sales_Territory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Capture event when CurrentInd switches to zero. In the absence of better info, it''s the ModifiedDate of the row when the change occurs.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmploymentEndDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowIsCurrent'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowStartDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowEndDate'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard SCD-2', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'RowChangeReason'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Track as Type 2 because source system doesn''t do so', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'NationalIDNumber'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Track as Type 2 because source system doesn''t do so', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BirthDate'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Track as Type 2 because source system doesn''t do so', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Gender'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Create initial history from EmployeeDepartmentHistory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentID'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'see above', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'Department'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'see above', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'DepartmentGroup'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Only employees who are salespeople are in SalesPerson', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKCurrentSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'We may want to do this decoding in the ETL; copy CountryRegion to staging area?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'CurrentSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Create initial history from Sales.SalesTerritoryHistory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'BKHistoricalSalesTerritoryId'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'see above', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritory'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'see above', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryCountry'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'see above', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HistoricalSalesTerritoryGroup'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Track as Type 2 because source system doesn''t do so', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'HireDate'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'This is a bad design for the trxn system. Pressure those guys to capture explicitly the employment end date. Capture initial history from EmployeeDepartmentHistory.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimEmployee', @level2type=N'COLUMN', @level2name=N'EmploymentEndDate'; 
GO





/* Drop table DimOrderInfo */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimOrderInfo]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimOrderInfo] 
GO

/* Create table DimOrderInfo */
CREATE TABLE [DimOrderInfo] (
   [OrderInfoKey]  smallint IDENTITY  NOT NULL
,  [BKSalesReasonID]  smallint   NOT NULL
,  [Channel]  char(8)   NULL
,  [SalesReason]  varchar(30)   NULL
,  [SalesReasonType]  char(10)   NULL
,  [AuditKey]  int   NOT NULL
, CONSTRAINT [PK_DimOrderInfo] PRIMARY KEY CLUSTERED 
( [OrderInfoKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'OrderInfo', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'OrderInfo is the "junk" dimension that includes miscellaneous information about the Order transaction', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'Orders', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo'
GO

SET IDENTITY_INSERT DimOrderInfo ON
GO
INSERT INTO DimOrderInfo (OrderInfoKey, BKSalesReasonID, Channel, SalesReason, SalesReasonType, AuditKey)
VALUES (-1, -1, 'Unknown', 'Unknown', 'Unknown', -1)
GO
SET IDENTITY_INSERT DimOrderInfo OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Sales reason ID from source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Sales channel', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Reason for the sale, as reported by the customer', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Type of sales reason', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What process loaded this row?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3, 4�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Reseller, Internet', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Marketing, Promotion, Other', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesReason', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesReason', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesReason', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesReason', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'SalesReasonID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ReasonType', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Standard surrogate key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Convert to char; left-pad with zero. R for reseller row.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Internet'' for real sales reasons. ''Reseller'' for reseller row.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'Channel'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'''Reseller'' for reseller row.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReason'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'''Reseller'' for reseller row', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'SalesReasonType'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Populated by ETL system using standard technique', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'We need to insert a single row for Reseller', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimOrderInfo', @level2type=N'COLUMN', @level2name=N'BKSalesReasonID'; 
GO





/* Drop table DimProduct */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimProduct]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimProduct] 
GO

/* Create table DimProduct */
CREATE TABLE [DimProduct] (
   [ProductKey]  int IDENTITY  NOT NULL
,  [BKProductID]  int   NOT NULL
,  [ProductSKU]  varchar(25)   NULL
,  [ProductName]  varchar(50)   NULL
,  [ProductDescr]  varchar(50)   NULL
,  [ProductModelID]  int   NULL
,  [Model]  varchar(50)   NULL
,  [ProductSubcategoryID]  int   NULL
,  [ProductSubcategory]  varchar(50)   NULL
,  [ProductCategoryID]  int   NULL
,  [ProductCategory]  varchar(50)   NULL
,  [ProductLine]  char(10)   NULL
,  [Color]  varchar(15)   NULL
,  [Class]  char(7)   NULL
,  [Style]  char(7)   NULL
,  [IsFinishedGood]  char(15)   NULL
,  [Size]  char(7)   NULL
,  [SizeRange]  varchar(20)   NULL
,  [SizeUnitOfMeasureCode]  char(3)   NULL
,  [Weight]  decimal(8,2)   NULL
,  [WeightUnitOfMeasureCode]  char(5)   NULL
,  [DaysToManufacture]  int   NULL
,  [StandardCost]  money   NULL
,  [ListPrice]  money   NULL
,  [DealerPrice]  money   NULL
,  [SafetyStockLevel]  smallint   NULL
,  [ReorderPoint]  smallint   NULL
,  [SellStartDate]  datetime   NULL
,  [SellEndDate]  datetime   NULL
,  [ProductCurrentStatus]  char(12)   NULL
,  [AuditKey]  int   NULL
, CONSTRAINT [PK_DimProduct] PRIMARY KEY CLUSTERED 
( [ProductKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Information about products', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'Orders', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct'
GO

SET IDENTITY_INSERT DimProduct ON
GO
INSERT INTO DimProduct (ProductKey, BKProductID, ProductSKU, ProductName, ProductDescr, ProductModelID, Model, ProductSubcategoryID, ProductSubcategory, ProductCategoryID, ProductCategory, ProductLine, Color, Class, Style, IsFinishedGood, Size, SizeRange, SizeUnitOfMeasureCode, Weight, WeightUnitOfMeasureCode, DaysToManufacture, StandardCost, ListPrice, DealerPrice, SafetyStockLevel, ReorderPoint, SellStartDate, SellEndDate, ProductCurrentStatus, AuditKey)
VALUES (-1, -1, 'Unknown', 'Unknown', 'Unknown', NULL, 'Unknown', NULL, 'Unknown', NULL, 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'Unknown', 'N/A', NULL, 'N/A', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, -1)
GO
SET IDENTITY_INSERT DimProduct OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'ProductID, Natural key from source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'BKProductID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'SKU, also known as Product Number', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSKU'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product English description', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product model ID from source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Model name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product subcategory ID from the source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product subcategory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product category ID from the source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategoryID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product category', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product line', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product color', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product class (H/M/L)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product style (Men/Women/Unisex)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is the product classified as a finished good?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Item size', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Grouping of item sizes for bikes, eg 38-40 cm', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeRange'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'How is size measured', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Item weight', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'How is weight measured?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Average days to manufacture', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Current standard cost of production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Current suggested list price', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Current price to dealers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DealerPrice'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'For AW warehouse, comfortable level of inventory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'For AW warehouse, reorder when stock falls below this point', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date product first available', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellStartDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Date product last available', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellEndDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product current status', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What process loaded this row?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Mountain, Road, Touring', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Silver, Red, Multi', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'High, Medium, Low', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Men, Women, Unisex', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Finished Good, Unfinished good', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Large, Medium, Small, 46, 70', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'CM, N/A', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1050', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'gram, pound, N/A', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3, 4', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'2171.29', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'3578.27', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1000', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'750', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Current, Discontinued', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSKU'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategoryID'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeRange'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DealerPrice'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellStartDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellEndDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'BKProductID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSKU'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeRange'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'BKProductID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSKU'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Production', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'BKProductID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSKU'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'ProductModel', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'ProductSubcategory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'ProductSubcategory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'ProductCategory', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'Product', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ProductID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'BKProductID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ProductNumber', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSKU'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ProductModelID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ProductSubcategoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ProductCategoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ProductLine', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Color', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Class', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Style', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'FinishedGoodsFlag', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Size', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'SizeUnitMeasureCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Weight', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'WeightUnitMeasureCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'DaysToManufacture', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'StandardCost', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ListPrice', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'SafetyStockLevel', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'ReorderPoint', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'SellStartDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'SellEndDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'DiscontinuedDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'BKProductID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(25)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSKU'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategoryID'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(2)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(15)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(2)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(2)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'bit', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(5)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(3)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'decimal(8,2)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Weight'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nchar(3)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DaysToManufacture'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'money', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'money', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'smallint', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SafetyStockLevel'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'smallint', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ReorderPoint'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'datetime', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'datetime', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SellEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'datetime', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Populate with the product name for now', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'NULL to -1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductModelID'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on Product.ProductModelID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Model'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'NULL to -1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategoryID'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on Product. ProductSubcategoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductSubcategory'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Join on ProductCategoryID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCategory'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode T=Touring, M=Mountain, R=Road, S=Accessory, NULL=Bike Part', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductLine'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Replace NULL with ''No color''', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Color'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode H/M/L/NULL as High/Medium/Low/None', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Class'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode M/W/U/NULL as Men/Women/Unisex/None', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Style'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode 1/0 to Finished Good/Unfinished good', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'IsFinishedGood'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode L/M/S/NULL to Large/Medium/Small/No Size; else keep Size', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'Size'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'???', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeRange'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode NULL to N/A', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'SizeUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Decode G=gram, LB=pound, NULL=N/A', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'WeightUnitOfMeasureCode'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'NULL for now', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DealerPrice'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'If DiscontinuedDate <> NULL then ''Discontinued'' ELSE ''Current''', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductCurrentStatus'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'We need a source for description.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ProductDescr'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Cost & price are in the Orders fact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'StandardCost'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Cost & price are in the Orders fact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'ListPrice'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Where does this come from?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimProduct', @level2type=N'COLUMN', @level2name=N'DealerPrice'; 
GO





/* Drop table DimPromotion */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimPromotion]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimPromotion] 
GO

/* Create table DimPromotion */
CREATE TABLE [DimPromotion] (
   [PromotionKey]  smallint IDENTITY  NOT NULL
,  [BKSpecialOfferID]  int   NOT NULL
,  [PromotionName]  varchar(50)   NULL
,  [PromotionType]  varchar(20)   NULL
,  [PromotionCategory]  varchar(20)   NULL
,  [DiscountPct]  smallmoney   NULL
,  [PromotionStartDate]  datetime   NULL
,  [PromotionEndDate]  datetime   NULL
,  [MinQty]  int   NULL
,  [MaxQty]  int   NULL
,  [AuditKey]  int   NOT NULL
, CONSTRAINT [PK_DimPromotion] PRIMARY KEY CLUSTERED 
( [PromotionKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'Promotion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Contains information about marketing promotions', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'Orders', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion'
GO

SET IDENTITY_INSERT DimPromotion ON
GO
INSERT INTO DimPromotion (PromotionKey, BKSpecialOfferID, PromotionName, PromotionType, PromotionCategory, DiscountPct, PromotionStartDate, PromotionEndDate, MinQty, MaxQty, AuditKey)
VALUES (-1, -1, 'Unknown', 'Unknown', 'Unknown', NULL, NULL, NULL, NULL, NULL, -1)
GO
SET IDENTITY_INSERT DimPromotion OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Natural key from source system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'BKSpecialOfferID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Promotion Name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Promo type', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Is promotion offered to resellers or directly to customers?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Promotion discount percent', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'DiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Promotion start date', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionStartDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Promotion end date', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionEndDate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Minimum quantity required for promotion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MinQty'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Maximum quantity permitted for promotion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'What process loaded this row?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'BKSpecialOfferID'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Mountain Tire Sale', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Volume Discount', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Reseller, Customer, No Discount', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'DiscountPct'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionStartDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionEndDate'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MinQty'; 
exec sys.sp_addextendedproperty @name=N'SCD  Type', @value=N'1', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'BKSpecialOfferID'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'DiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MinQty'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived in ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'BKSpecialOfferID'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'DiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MinQty'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'BKSpecialOfferID'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'DiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MinQty'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SpecialOffers', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Description', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Type', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Category', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'DiscountPct', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'DiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'StartDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'EndDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'MinQty', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MinQty'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'MaxQty', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(255)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionType'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'nvarchar(50)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionCategory'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'smallmoney', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'DiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'datetime', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionStartDate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'datetime', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionEndDate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MinQty'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Check for overflows', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'PromotionName'; 
exec sys.sp_addextendedproperty @name=N'ETL Rules', @value=N'Convert NULL to MaxInt', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimPromotion', @level2type=N'COLUMN', @level2name=N'MaxQty'; 
GO





/* Drop table DimAudit */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DimAudit]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [DimAudit] 
GO

/* Create table DimAudit */
CREATE TABLE [DimAudit] (
   [AuditKey]  int IDENTITY  NOT NULL
,  [TableProcessKey]  int   NOT NULL
,  [BranchName]  varchar(50)   NOT NULL
,  [BranchRowCnt]  int   NULL
,  [ProcessingSummaryGroup]  varchar(25)   NOT NULL
, CONSTRAINT [PK_DimAudit] PRIMARY KEY CLUSTERED 
( [AuditKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Audit dimension tags each data row with the the process that added or updated it.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'All', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit'
GO

SET IDENTITY_INSERT DimAudit ON
GO
INSERT INTO DimAudit (AuditKey, TableProcessKey, BranchName, BranchRowCnt, ProcessingSummaryGroup)
VALUES (-1, -1, 'Test', NULL, 'Test')
GO
SET IDENTITY_INSERT DimAudit OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Foreign key to AuditTableProcessing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'TableProcessKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Name supplied by the ETL developer for branch that adds / updates data in the target table', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'BranchName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Count of rows added/updated in this package branch', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'BranchRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'When we summarize rowcounts in AuditTableProcessing, is this branch considered "standard" or "non-standard"?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'ProcessingSummaryGroup'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'AuditTableProcessing.TableProcessKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'TableProcessKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Standard, Non-standard', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'ProcessingSummaryGroup'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'DimAudit', @level2type=N'COLUMN', @level2name=N'AuditKey'; 
GO





/* Drop table AuditTableProcessing */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AuditTableProcessing]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [AuditTableProcessing] 
GO

/* Create table AuditTableProcessing */
CREATE TABLE [AuditTableProcessing] (
   [TableProcessKey]  int IDENTITY  NOT NULL
,  [PkgExecKey]  int   NOT NULL
,  [TableName]  varchar(50)   NULL
,  [ExtractRowCnt]  int   NULL
,  [ExtractCheckValue1]  float   NULL
,  [ExtractCheckValue2]  float   NULL
,  [InsertStdRowCnt]  int   NULL
,  [InsertStdCheckValue1]  float   NULL
,  [InsertStdCheckValue2]  float   NULL
,  [InsertNonstdRowCnt]  int   NULL
,  [InsertNonstdCheckValue1]  float   NULL
,  [InsertNonstdCheckValue2]  float   NULL
,  [UpdateRowCnt]  int   NULL
,  [ErrorRowCnt]  int   NULL
,  [TableInitialRowCnt]  int   NULL
,  [TableFinalRowCnt]  int   NULL
,  [SuccessfulProcessingInd]  char(1)   NULL
, CONSTRAINT [PK_AuditTableProcessing] PRIMARY KEY CLUSTERED 
( [TableProcessKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Audit', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Receives a row each time a table is processed in a package', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'All', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing'
GO

SET IDENTITY_INSERT AuditTableProcessing ON
GO
INSERT INTO AuditTableProcessing (TableProcessKey, PkgExecKey, TableName, ExtractRowCnt, ExtractCheckValue1, ExtractCheckValue2, InsertStdRowCnt, InsertStdCheckValue1, InsertStdCheckValue2, InsertNonstdRowCnt, InsertNonstdCheckValue1, InsertNonstdCheckValue2, UpdateRowCnt, ErrorRowCnt, TableInitialRowCnt, TableFinalRowCnt, SuccessfulProcessingInd)
VALUES (-1, -1, 'Unknown', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT AuditTableProcessing OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableProcessKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Foreign key to AuditPkgExecution', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'PkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Table name', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Count of rows extracted from the source', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ExtractRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Check value of ETL designer''s choice, eg Sum(SalesAmt), upon extract', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ExtractCheckValue1'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Check value of ETL designer''s choice, eg Max(SalesAmt), upon extract', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ExtractCheckValue2'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Count of rows inserted into target using standard processing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertStdRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Check value of ETL designer''s choice, eg Sum(SalesAmt), upon standard insert', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertStdCheckValue1'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Check value of ETL designer''s choice, eg Max(SalesAmt), upon standard insert', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertStdCheckValue2'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Count of rows inserted into target using a non-standard branch of the ETL system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertNonstdRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Check value of ETL designer''s choice, eg Sum(SalesAmt), upon non-standard insert', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertNonstdCheckValue1'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Check value of ETL designer''s choice, eg Max(SalesAmt), upon non-standard insert', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertNonstdCheckValue2'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Count of rows updated in target table', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'UpdateRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Count of error rows not inserted into table', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ErrorRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Initial row count of target table, pre-processing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableInitialRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Final row count of target table, post processing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableFinalRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Did this table finish processing successfully?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'SuccessfulProcessingInd'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'AuditPkgExecution.PkgExecKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'PkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableProcessKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'SuccessfulProcessingInd'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableProcessKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'PkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableName'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ExtractRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ExtractCheckValue1'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ExtractCheckValue2'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertStdRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertStdCheckValue1'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertStdCheckValue2'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertNonstdRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertNonstdCheckValue1'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'InsertNonstdCheckValue2'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'UpdateRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'ErrorRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableInitialRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'TableFinalRowCnt'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditTableProcessing', @level2type=N'COLUMN', @level2name=N'SuccessfulProcessingInd'; 
GO





/* Drop table AuditPkgExecution */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[AuditPkgExecution]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [AuditPkgExecution] 
GO

/* Create table AuditPkgExecution */
CREATE TABLE [AuditPkgExecution] (
   [PkgExecKey]  int IDENTITY  NOT NULL
,  [PkgName]  varchar(50)   NULL
,  [PkgGUID]  uniqueidentifier   NULL
,  [PkgVersionGUID]  uniqueidentifier   NULL
,  [PkgVersionMajor]  smallint   NULL
,  [PkgVersionMinor]  smallint   NULL
,  [ExecStartDT]  datetime   NULL
,  [ExecStopDT]  datetime   NULL
,  [SuccessfulProcessingInd]  char(1)   NULL
,  [ParentPkgExecKey]  int   NULL
, CONSTRAINT [PK_AuditPkgExecution] PRIMARY KEY CLUSTERED 
( [PkgExecKey] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Audit', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Receives a row each time an Integration Services package is executed', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution'
exec sys.sp_addextendedproperty @name=N'Used in schemas', @value=N'All', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution'
GO

SET IDENTITY_INSERT AuditPkgExecution ON
GO
INSERT INTO AuditPkgExecution (PkgExecKey, PkgName, PkgGUID, PkgVersionGUID, PkgVersionMajor, PkgVersionMinor, ExecStartDT, ExecStopDT, SuccessfulProcessingInd, ParentPkgExecKey)
VALUES (-1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
GO
SET IDENTITY_INSERT AuditPkgExecution OFF
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Surrogate primary key', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Name of the package', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgName'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'GUID for the package', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgGUID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Package version GUID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgVersionGUID'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Package major version', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgVersionMajor'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Package minor version', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgVersionMinor'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Datetime package execution began', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'ExecStartDT'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Datetime package execution ended', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'ExecStopDT'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Did package execution complete without error?', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'SuccessfulProcessingInd'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Link to the row for the master package execution that called this package', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'ParentPkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'AuditPkgExecution.PkgExecKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'ParentPkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3�', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Dim_Product_ETL', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgName'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgVersionMajor'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgVersionMinor'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'Y, N', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'SuccessfulProcessingInd'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'ParentPkgExecKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'AuditPkgExecution', @level2type=N'COLUMN', @level2name=N'PkgExecKey'; 
GO





/* Drop table FactOrders */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[FactOrders]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [FactOrders] 
GO

/* Create table FactOrders */
CREATE TABLE [FactOrders] (
   [ProductKey]  int   NOT NULL
,  [CustomerKey]  int   NOT NULL
,  [OrderDateKey]  int   NOT NULL
,  [DueDateKey]  int   NOT NULL
,  [OrderInfoKey]  smallint   NOT NULL
,  [PromotionKey]  smallint   NOT NULL
,  [CurrencyKey]  smallint   NOT NULL
,  [SalesRepKey]  int   NOT NULL
,  [InsertAuditKey]  int   NOT NULL
,  [UpdateAuditKey]  int  DEFAULT -1 NOT NULL
,  [SalesOrderNum]  int   NOT NULL
,  [SalesOrderLineNum]  int   NOT NULL
,  [SalesOrderRevisionNum]  tinyint   NOT NULL
,  [OrderQty]  smallint   NULL
,  [UnitPriceUSD]  money   NULL
,  [ExtendedAmtUSD]  money   NULL
,  [UnitPriceDiscountPct]  float   NULL
,  [DiscountUSD]  money   NULL
,  [ProductStdCostUSD]  money   NULL
,  [TotalProductCostUSD]  money   NULL
,  [SalesAmtUSD]  money   NULL
,  [SalesAmtLocal]  money   NULL
,  [TaxUSD]  money   NULL
,  [TaxLocal]  money   NULL
,  [FreightUSD]  money   NULL
,  [FreightLocal]  money   NULL
,  [CustomerPONum]  varchar(25)   NULL
, CONSTRAINT [PK_FactOrders] PRIMARY KEY NONCLUSTERED 
( [SalesOrderNum], [SalesOrderLineNum], [SalesOrderRevisionNum] )
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Fact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'Orders', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'FactOrders captures order transactions at the order line item level', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders'
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Product dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Customer dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Date dim', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderDateKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Date dim', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DueDateKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to OrderInfo dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Promotion dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Currency dim', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Employee dimension', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesRepKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Audit dimension for row insertion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Audit dim for row last updated', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Sales order number from trxn system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderNum'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Sales order line number', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderLineNum'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Sales order revision number', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderRevisionNum'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Quantity of this item in this order', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderQty'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Standard price for this item', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Price * Quantity', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ExtendedAmtUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Discount % applied to this line item in this order, if any', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Discount in US Dollars', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DiscountUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Product''s cost of goods sold', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductStdCostUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'COGS * Quantity', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TotalProductCostUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'ExtendedAmt adjusted for discounts (LineTotal from the trxn system)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesAmtUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Sales Amount, in local currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesAmtLocal'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Tax Amount, prorated across items in the order', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Tax Amount, in local currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxLocal'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Freight Amount, prorated across items in the order', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightUSD'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Freight Amount, in local currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightLocal'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Purchase Order Number from the transaction system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerPONum'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimProduct.ProductKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimCustomer.CustomerKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimDate.DateKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderDateKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimDate.DateKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DueDateKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimOrderInfo.OrderInfoKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimPromotion.PromotionKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimCurrency.CurrencyKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimEmployee.EmployeeKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesRepKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderDateKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DueDateKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesRepKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderNum'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderLineNum'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderRevisionNum'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderDateKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DueDateKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesRepKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderNum'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderLineNum'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderRevisionNum'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderQty'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ExtendedAmtUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DiscountUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'DW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductStdCostUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TotalProductCostUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesAmtUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesAmtLocal'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxLocal'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightUSD'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'Derived', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightLocal'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'AW', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerPONum'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderNum'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderLineNum'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderRevisionNum'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderQty'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxLocal'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightLocal'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerPONum'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderHeader', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderNum'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderHeader', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderLineNum'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderDetail', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderRevisionNum'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderDetail', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderQty'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderDetail', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderDetail', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DiscountUSD'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'DimProduct', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductStdCostUSD'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderDetail', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxUSD'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderHeader', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxLocal'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderHeader', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightLocal'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'SalesOrderHeader', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerPONum'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'SalesOrderID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderNum'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'RevisionNumber', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderLineNum'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'LineNumber', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderRevisionNum'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'OrderQty', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderQty'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'UnitPriceDiscount', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'UnitPriceDiscount', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DiscountUSD'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'StandardCost', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductStdCostUSD'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'TaxAmt', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxUSD'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'TaxAmt', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxLocal'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'Freight', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightLocal'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'PurchaseOrderNumber', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerPONum'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'int', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderNum'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'tinyint', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderLineNum'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'tinyint', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesOrderRevisionNum'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'money', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'money', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DiscountUSD'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderDetail.ProductID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ProductKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderHeader.CustomerID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CustomerKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderHeader.OrderDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderDateKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderHeader.DueDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DueDateKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderHeaderSalesReason.SalesReasonID (first reason)', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderDetail.SpecialOfferID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'PromotionKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderHeader.CurrencyRateID to Sales.CurrencyRate; pick up FromCurrencyCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from SalesOrderHeader.SalesPersonID', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesRepKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Standard auditing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Standard auditing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'UnitPriceUSD * OrderQty', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'ExtendedAmtUSD'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Convert currency to float', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'UnitPriceDiscountPct * ExtendedAmtUSD', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'DiscountUSD'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'ProductStdCostUSD * OrderQty', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TotalProductCostUSD'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'ExtendedAmtUSD - DiscountUSD', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesAmtUSD'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Convert SalesAmtUSD to local currency based on lookup to DimCurrency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesAmtLocal'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Allocate TaxAmt to line item level based on this item''s $ contribution to the total sale', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxUSD'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'ConvertTaxUSD to local currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'TaxLocal'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Allocate Freight to line item level based on this item''s $ contribution to the total sale', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightUSD'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Convert FreightUSD to local currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightLocal'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'We''ve asked the trxn system folks to modify their application to capture a primary sales reason. Until then, we''ll populate this with the first sales reason.', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'OrderInfoKey'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Though it''s a money data type in the source, this is a %', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'UnitPriceDiscountPct'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Verify this matches with LineTotal from trxn system', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'SalesAmtLocal'; 
exec sys.sp_addextendedproperty @name=N'Comments', @value=N'Allocating based on weight would probably be better. ', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactOrders', @level2type=N'COLUMN', @level2name=N'FreightUSD'; 
GO





/* Drop table FactExchangeRates */
IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[FactExchangeRates]') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
DROP TABLE [FactExchangeRates] 
GO

/* Create table FactExchangeRates */
CREATE TABLE [FactExchangeRates] (
   [CurrencyKey]  smallint   NOT NULL
,  [DateKey]  int   NOT NULL
,  [InsertAuditKey]  int   NOT NULL
,  [UpdateAuditKey]  int  DEFAULT -2 NOT NULL
,  [CloseRate]  float   NULL
,  [AvgRate]  float   NULL
) ON [PRIMARY]
GO

exec sys.sp_addextendedproperty @name=N'Table Type', @value=N'Fact', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates'
exec sys.sp_addextendedproperty @name=N'View Name', @value=N'ExchangeRates', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates'
exec sys.sp_addextendedproperty @name=N'Description', @value=N'FactExchangeRates captures daily exchange rates to/from USD', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates'
GO

exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Currency dim', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Date dim', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Audit dimension for row insertion', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Key to Audit dim for row last updated', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Market close (end of day) exchange rate from USD to local currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CloseRate'; 
exec sys.sp_addextendedproperty @name=N'Description', @value=N'Average daily exchange rate from USD to local currency', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'AvgRate'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimCurrency.CurrencyKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimDate.DateKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'FK To', @value=N'DimAudit.AuditKey', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Example Values', @value=N'1, 2, 3', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source System', @value=N'ETL Process', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CloseRate'; 
exec sys.sp_addextendedproperty @name=N'Source Schema', @value=N'Sales', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'AvgRate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CurrencyRate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CloseRate'; 
exec sys.sp_addextendedproperty @name=N'Source Table', @value=N'CurrencyRate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'AvgRate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'EndOfDayRate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CloseRate'; 
exec sys.sp_addextendedproperty @name=N'Source Field Name', @value=N'AverageRate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'AvgRate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'money', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CloseRate'; 
exec sys.sp_addextendedproperty @name=N'Source Datatype', @value=N'money', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'AvgRate'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from Sales.CurrencyRate.FromCurrencyCode', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'CurrencyKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Key lookup from Sales.CurrencyRate.CurrencyRateDate', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'DateKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Standard auditing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'InsertAuditKey'; 
exec sys.sp_addextendedproperty @name=N'Extraction/Transformation Rules', @value=N'Standard auditing', @level0type=N'SCHEMA', @level0name=N'dbo', @level1type=N'TABLE', @level1name=N'FactExchangeRates', @level2type=N'COLUMN', @level2name=N'UpdateAuditKey'; 
GO
ALTER TABLE DimCustomer ADD CONSTRAINT
   FK_DimCustomer_AuditKey FOREIGN KEY
   (
   AuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE DimCurrency ADD CONSTRAINT
   FK_DimCurrency_AuditKey FOREIGN KEY
   (
   AuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE DimDate ADD CONSTRAINT
   FK_DimDate_AuditKey FOREIGN KEY
   (
   AuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE DimEmployee ADD CONSTRAINT
   FK_DimEmployee_AuditKey FOREIGN KEY
   (
   AuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE DimOrderInfo ADD CONSTRAINT
   FK_DimOrderInfo_AuditKey FOREIGN KEY
   (
   AuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE DimProduct ADD CONSTRAINT
   FK_DimProduct_AuditKey FOREIGN KEY
   (
   AuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE DimPromotion ADD CONSTRAINT
   FK_DimPromotion_AuditKey FOREIGN KEY
   (
   AuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE DimAudit ADD CONSTRAINT
   FK_DimAudit_TableProcessKey FOREIGN KEY
   (
   TableProcessKey
   ) REFERENCES AuditTableProcessing
   ( TableProcessKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE AuditTableProcessing ADD CONSTRAINT
   FK_AuditTableProcessing_PkgExecKey FOREIGN KEY
   (
   PkgExecKey
   ) REFERENCES AuditPkgExecution
   ( PkgExecKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE AuditPkgExecution ADD CONSTRAINT
   FK_AuditPkgExecution_ParentPkgExecKey FOREIGN KEY
   (
   ParentPkgExecKey
   ) REFERENCES AuditPkgExecution
   ( PkgExecKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_ProductKey FOREIGN KEY
   (
   ProductKey
   ) REFERENCES DimProduct
   ( ProductKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_CustomerKey FOREIGN KEY
   (
   CustomerKey
   ) REFERENCES DimCustomer
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_OrderDateKey FOREIGN KEY
   (
   OrderDateKey
   ) REFERENCES DimDate
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_DueDateKey FOREIGN KEY
   (
   DueDateKey
   ) REFERENCES DimDate
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_OrderInfoKey FOREIGN KEY
   (
   OrderInfoKey
   ) REFERENCES DimOrderInfo
   ( OrderInfoKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_PromotionKey FOREIGN KEY
   (
   PromotionKey
   ) REFERENCES DimPromotion
   ( PromotionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_CurrencyKey FOREIGN KEY
   (
   CurrencyKey
   ) REFERENCES DimCurrency
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_SalesRepKey FOREIGN KEY
   (
   SalesRepKey
   ) REFERENCES DimEmployee
   ( EmployeeKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactOrders ADD CONSTRAINT
   FK_FactOrders_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactExchangeRates ADD CONSTRAINT
   FK_FactExchangeRates_CurrencyKey FOREIGN KEY
   (
   CurrencyKey
   ) REFERENCES DimCurrency
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactExchangeRates ADD CONSTRAINT
   FK_FactExchangeRates_DateKey FOREIGN KEY
   (
   DateKey
   ) REFERENCES DimDate
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactExchangeRates ADD CONSTRAINT
   FK_FactExchangeRates_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
ALTER TABLE FactExchangeRates ADD CONSTRAINT
   FK_FactExchangeRates_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES DimAudit
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
GO
 
