The Microsoft Data Warehouse Toolkit
Data Profiler Reporting Services Report Project

Source location: Chapter 2 Downloads

Disclaimer
----------
This report set is meant to provide an example of data profiling. It is a simple data profiler with limited functionality. It assumes the user has appropriate privileges and does little error checking. Use at your own risk.


Instructions
------------
1) Install the two stored procedures in the target database
2) Open the Data Profiler Reporting Services project. Change the target directory if necessary, and Deploy the project.
3) Go to the Report Manager and test the reports. Remember, they may take a while to run if your tables are particularly large. 

Enhancements
------------
These reports could be a lot better. Please let us know if you create any useful enhancements or extensions to this report set.

Visit the book's website at http://www.msftDWToolkit.com to submit any enhancements and download any updates.
